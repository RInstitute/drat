# RcppArrayFire 0.1.0

* Support for sparse matrices (Kazuki Fukui in [#9](https://github.com/daqana/rcpparrayfire/pull/9))
* Support MacOS (Ralf in [#5](https://github.com/daqana/rcpparrayfire/pull/5))

# RcppArrayFire 0.0.3

* Expanded the vignette
* Fixed bug w.r.t. range adjustment for uniform random numbers
* Corrected handling of the `configure` option `--with-arrayfire`
* Added a `NEWS.md` file to track changes to the package.



