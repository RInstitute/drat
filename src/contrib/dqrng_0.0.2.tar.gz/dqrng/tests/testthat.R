library(testthat)
library(dqrng)

test_check("dqrng")
