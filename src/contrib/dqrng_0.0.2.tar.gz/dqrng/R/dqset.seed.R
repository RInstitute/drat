#' @export
#' @rdname dqrng
dqset.seed <- function(seed) {
  dqset_seed(seed)
}
