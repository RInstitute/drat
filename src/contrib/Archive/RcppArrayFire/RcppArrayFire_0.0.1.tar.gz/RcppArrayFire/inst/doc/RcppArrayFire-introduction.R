## ---- eval = FALSE-------------------------------------------------------
#  library(RcppArrayFire)
#  src <- 'af::array doubleArray(const RcppArrayFire::typed_array<f32>& x) {
#      return 2 * x;
#  }'
#  
#  Rcpp::cppFunction(code = src, depends = "RcppArrayFire")
#  doubleArray(array(1:8, dim = c(2, 4)))

