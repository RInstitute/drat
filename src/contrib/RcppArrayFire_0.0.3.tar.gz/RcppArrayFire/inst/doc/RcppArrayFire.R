## ---- eval = FALSE-------------------------------------------------------
#  piR <- function(N) {
#      x <- runif(N)
#      y <- runif(N)
#      4 * sum(sqrt(x^2 + y^2) < 1.0) / N
#  }
#  
#  set.seed(42)
#  system.time(cat("pi ~= ", piR(10^7), "\n"))
#  #> pi ~=  3.140899
#  #>        user      system     elapsed
#  #>       0.836       0.060       0.897

## ---- eval = FALSE-------------------------------------------------------
#  src <- '
#  double piAF (const int N) {
#      array x = randu(N, f32);
#      array y = randu(N, f32);
#      return 4.0 * sum<float>(sqrt(x*x + y*y) < 1.0) / N;
#  }'
#  Rcpp::cppFunction(code = src, depends = "RcppArrayFire", includes = "using namespace af;")
#  
#  RcppArrayFire::arrayfire_set_seed(42)
#  system.time(cat("pi ~= ", piAF(10^7), "\n"))
#  #> pi ~=  3.141066
#  #>        user      system     elapsed
#  #>       0.000       0.004       0.021

## ---- eval = FALSE-------------------------------------------------------
#  set.seed(42)
#  N <- 40
#  X <- matrix(rnorm(N * N * 2), ncol = N)
#  tXXR <- t(X) %*% X

## ---- eval = FALSE-------------------------------------------------------
#  src <- '
#  af::array squareMatrix(const RcppArrayFire::typed_array<f32>& x) {
#      return af::matmulTN(x ,x);
#  }'
#  Rcpp::cppFunction(code = src, depends = "RcppArrayFire")
#  tXXGPU <- squareMatrix(X)
#  
#  all.equal(tXXR, tXXGPU)
#  #> [1] "Mean relative difference: 1.372856e-07"

## ---- eval = FALSE-------------------------------------------------------
#  src <- '
#  af::array squareMatrixF64(const RcppArrayFire::typed_array<f64>& x) {
#      return af::matmulTN(x ,x);
#  }'
#  Rcpp::cppFunction(code = src, depends = "RcppArrayFire")
#  
#  RcppArrayFire::arrayfire_set_backend("CPU")
#  tXXCPU <- squareMatrixF64(X)
#  RcppArrayFire::arrayfire_set_backend("DEFAULT")
#  
#  all.equal(tXXR, tXXCPU)
#  #> [1] TRUE

