# RcppArrayFire 0.0.3

* Expanded the vignette
* Fixed bug w.r.t. range adjustment for uniform random numbers
* Corrected handling of the `configure` option `--with-arrayfire`
* Added a `NEWS.md` file to track changes to the package.



