#include <iostream>
#include <cassert>

#include <arrayfire.h>

float uchi2(af::array input, uint32_t expected) {
    assert(input.isvector());
    // dim_t bins = input.dims(0);
    af::array diff1 = input - expected;
    af::array diff2 = expected - input;
    af::array cond = (input >= expected);
    af::array diff = af::select(cond, diff1, diff2);
    // af::array diff = af::select((input >= expected),
    //                             (input - expected),
    //                             (expected - input));
    return af::sum<float>((diff * diff) / static_cast<float>(expected));
}



int main(int argc, char ** argv) {
    int backend = argc > 1 ? atoi(argv[1]) : 0;
    af::setBackend(static_cast<af::Backend>(backend));
    int device = argc > 2 ? atoi(argv[2]) : 0;
    af::setDevice(device);
    af::info();

    uint32_t samples = 100000000;
    uint32_t steps = 500;
    uint32_t bins = 100;
    uint32_t expected = 0;

    af::array total_hist = af::constant(0, bins, u32);
    af::array step_hist = af::constant(0, bins, u32);
    af::array sample = af::constant(0, samples, f32);

    // af::setRandomEngine
    // af::setSeed
    std::cout << "Step,chi2,total chi2" << std::endl;
    for(int i = 0; i < steps; ++i) {
        sample = af::randu(samples);
        step_hist = af::histogram(sample, bins, 0.0, 1.0);
        total_hist += step_hist;
        expected += samples/bins;
        std::cout << i << ","
                  << uchi2(step_hist, samples/bins) << ","
                  << uchi2(total_hist, expected) << std::endl;
    }

}
