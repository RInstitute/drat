#include <arrayfire.h>

int main() {
    af::setDefaultRandomEngineType(AF_RANDOM_ENGINE_PHILOX);
    return 0;
}
