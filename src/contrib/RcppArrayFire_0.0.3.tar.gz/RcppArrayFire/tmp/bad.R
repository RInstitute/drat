library(RcppArrayFire)
arrayfire_get_rng_type()
