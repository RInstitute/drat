#include <arrayfire.h>

int main() {
    af::randomEngine engine = af::getDefaultRandomEngine();
    return 0;
}
