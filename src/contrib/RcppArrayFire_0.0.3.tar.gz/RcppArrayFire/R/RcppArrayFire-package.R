##' Rcpp integration for ArrayFire
##'
##' The RcppArrayFire package provides Rcpp integration for ArrayFire.
##'
##' @useDynLib RcppArrayFire, .registration = TRUE
##' @importFrom Rcpp evalCpp
"_PACKAGE"
