dyn.load("minimal.so")
.Call("count_backends")
