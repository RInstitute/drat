rm minimal*o
export PKG_LIBS="-laf"
R CMD SHLIB minimal.c
R -f minimal.R
