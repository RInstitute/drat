#include <arrayfire.h>
#include <Rinternals.h>
SEXP count_backends() {
  unsigned int count;
  af_get_backend_count(&count);
  Rprintf("backends: %d\n", count);
  return R_NilValue;
}
