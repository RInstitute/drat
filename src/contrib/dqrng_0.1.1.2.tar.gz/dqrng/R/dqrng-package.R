#' @useDynLib dqrng, .registration = TRUE
#' @importFrom Rcpp evalCpp
"_PACKAGE"
