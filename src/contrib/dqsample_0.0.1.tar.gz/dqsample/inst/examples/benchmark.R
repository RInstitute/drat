m <- 2/5 * 2^32
bench::mark(orig = dqsample:::sample_int(m, 1000000, replace = TRUE),
            base = base:::sample.int(m, 1000000, replace = TRUE),
            check = FALSE)
