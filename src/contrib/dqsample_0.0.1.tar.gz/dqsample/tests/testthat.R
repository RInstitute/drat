library(testthat)
library(dqsample)

test_check("dqsample")
