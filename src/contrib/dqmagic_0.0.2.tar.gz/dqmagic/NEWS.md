# dqmagic 0.0.2

* Compatibility with R 3.3

# dqmagic 0.0.1

* Add possibility to get MIME type and/or encoding
* Support vector of files as input

# dqmagic 0.0.0

* Initial version with basic file_type() function.
