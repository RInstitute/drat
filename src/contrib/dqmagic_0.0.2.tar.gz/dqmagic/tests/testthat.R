library(testthat)
library(dqmagic)

test_check("dqmagic")
